#include "sockettest.h"
#include <QApplication>
#include "QMediaPlayer"
#include "QVideoWidget"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    sockettest w;
    w.show();
//    sockettest cTest;
//    cTest.connectServer();


    return a.exec();

}
