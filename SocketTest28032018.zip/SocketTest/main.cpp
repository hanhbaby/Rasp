#include "sockettest.h"
#include <QApplication>
#include "QMediaPlayer"
#include "QVideoWidget"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//    sockettest w;
//    w.show();
//    sockettest cTest;
//    cTest.connectServer();

    QVideoWidget * video_widget = new QVideoWidget();
    video_widget->setGeometry(100, 100, 320,240);
    qDebug() << __LINE__;
//    QMediaPlayer * media_player = new QMediaPlayer(NULL, QMediaPlayer::VideoSurface);
//   //QString rtsp_url = QString("http://192.168.1.11:8080/stream_simple.html");
//    qDebug() << __LINE__;
//    media_player->setMedia(QUrl::fromLocalFile("/home/pi/video1.mp4"));
//    qDebug() << __LINE__;
//    media_player->setVideoOutput(video_widget);
//    qDebug() << __LINE__;
//    media_player->play();
//    qDebug() << media_player->state();
//    qDebug() << __LINE__;
    video_widget->show();
    qDebug() << __LINE__;

}
