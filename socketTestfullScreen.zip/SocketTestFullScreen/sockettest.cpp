/* Le Thi Hanh */
// 13.03,2018 test socket da run nhan message tu sever
//14.03.2018 giao tiep tung messsge theo tung nut nhan tren giao dien
//15.03.2018 nhan file image tu server
//24.03.2018 display video loi k tim dc qmediaplayer
//25.03.2018 hoan thien form Gui
//03.03.2018 display video stream
//04.03.2018 display audio
//05.03.2018 co the chay song song audio stream video dong thoi gui messenger
// chat luong video va am thanh deu tot, video delay 0.5s
//05.03.2018 hoan thanh task nhiem vu ben trong he thong
/*----------------------------------------------------------------------------*/
#include "sockettest.h"
#include "ui_sockettest.h"
#include "QVBoxLayout"
#include "QVideoWidget"
#define address "192.168.1.10"
#define port 8088

sockettest::sockettest(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::sockettest)
{

    ui->setupUi(this);
    QPixmap pix1(":/fptlogo.png");
    ui->logofpt->setPixmap(pix1);
    QPixmap pix2(":/dtvtlogo.png");
    ui->logodtvt->setPixmap(pix2);

    /* audio
    player = new QMediaPlayer(NULL, QMediaPlayer::StreamPlayback);
    player->setMedia(QUrl("http://192.168.1.15:8888/out.mp3"));
    player->setVolume(100);
   */
    /*video*/
    video_widget = new QVideoWidget(this);
    mlayout = new QVBoxLayout(this);
    media_player = new QMediaPlayer(NULL, QMediaPlayer::VideoSurface);
}

sockettest::~sockettest()
{
    delete ui;
}
void sockettest::connectServer()
{
    socket = new QTcpSocket(this);
    socket->connectToHost(address,port);
    if(socket->waitForConnected(3000))
    {
        socket->waitForReadyRead(3000);
        qDebug() << "reading"<< socket->bytesAvailable() ;
        if (socket->bytesAvailable() > 0)
        {
           qDebug() << socket->readAll();
        }
    }
    else
    {
        qDebug()<< "can't connected";
    }
}
void sockettest::on_btnLock_clicked()
{
    if(ui->btnLock->text() == "unLock")
    {
        ui->btnLock->setText("lock");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("lock door");
            socket->flush();
            socket->waitForBytesWritten(1000);
        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
    else
    {
        ui->btnLock->setText("unLock");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("unlock door");
            socket->flush();
            socket->waitForBytesWritten(1000);
        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
}

void sockettest::on_btnVideo_clicked()
{
    socket = new QTcpSocket(this);
    socket->connectToHost(address,port);
    if(ui->btnVideo->text() == "playVideo")
    {
        ui->btnVideo->setText("stopVideo");
        if(socket->waitForConnected(3000))
        {
            socket->write("playVideo");
            socket->flush();
            socket->waitForBytesWritten(3000);
        }
        else
        {
            qDebug() << "can't connect";
        }
        media_player->setMedia(QUrl("http://192.168.1.10:8080/?action=stream"));
        media_player->setVideoOutput(video_widget);
        mlayout->addWidget(video_widget);
        mlayout->setMargin(0);
        ui->video->setLayout(mlayout);
        media_player->play();
    }
    else
    {
        ui->btnVideo->setText("playVideo");
        if(socket->waitForConnected(3000))
        {
            socket->write("stopVideo");
            socket->flush();
            socket->waitForBytesWritten(3000);
        }
        else
        {
            qDebug() << "can't connect";
        }
         media_player->stop();
    }
}
void sockettest::on_btnAudio_clicked()
{

    socket = new QTcpSocket(this);

     socket->connectToHost(address,port);
    if(ui->btnAudio->text() == "on")
    {
        ui->btnAudio->setText("off");
        if(socket->waitForConnected(3000))
        {
            socket->write("turnonsound");
            socket->waitForBytesWritten(1000);
            socket->waitForReadyRead(3000);
        }
        else
        {
            qDebug()<< "can't connected";
        }

        //player->play();
    }
    else
    {
        ui->btnAudio->setText("on");
        //player->stop();
    }

}

