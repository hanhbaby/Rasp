#ifndef person_h
#define person_h

#define MAX_TEN 50 
#define MAX_MASO 5 
#define MUC_CO_BAN 120000 

class Nguoi 
{ 
	protected: 
		char HoTen[MAX_TEN];
		char MaSo[MAX_MASO]; 
		float Luong; 
	public: 
		Nguoi(); 
		virtual void TinhLuong()=0;
		void Xuat() const; 
		virtual void Nhap(); 
};
#endif
