#include "staff.h" 

#include <iostream>
using namespace std;

BienChe::BienChe()
{ 
	HeSoLuong=HeSoPhuCap=0; 
} 
void BienChe::Nhap()
{ 
	Nguoi::Nhap();
	cout<<"He so luong:"; 
	cin>>HeSoLuong; 
	cout<<"He so phu cap chu vu:"; 
	cin>>HeSoPhuCap; 
} 
void BienChe::TinhLuong() 
{ 
	Luong=MUC_CO_BAN*(1.0+HeSoLuong+HeSoPhuCap);
} 
