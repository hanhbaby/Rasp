#include "contract.h"
#include <iostream>
using namespace std;
  
 HopDong::HopDong() 
{ 
	TienCong=NgayCong=HeSoVuotGio=0; 
} 
void HopDong::Nhap() 
{ 
	Nguoi::Nhap(); 
	cout<<"Tien cong:"; 
	cin>>TienCong; 
	cout<<"Ngay cong:"; 
	cin>>NgayCong; 
	cout<<"He so vuot gio:"; 
	cin>>HeSoVuotGio; 
} 
void HopDong::TinhLuong() 
{ 
	Luong=TienCong*NgayCong*(1+HeSoVuotGio); 
} 
	    
