#include <iostream>
#include <ctype.h>
#include <conio.h>
#include "person.h"
#include "staff.h"
#include "contract.h" 

using namespace std;

int main(int argc, char** argv) 
{
	Nguoi *Ng[100]; 
	int N=0;
	char Chon,Loai; 
	do 
	{
		cout << "Bien che hay Hop dong (B/H)? ";
		cin>>Loai; 
		Loai=toupper(Loai); 
		if (Loai=='B') 
		{
			Ng[N]=new BienChe; 
		}
		else 
		{
			Ng[N]=new HopDong; 
		}
		Ng[N++]->Nhap(); 
		cout<<"Tiep tuc (C/K)? "; 
		cin>>Chon;
		Chon=toupper(Chon); 
		if ((N==100)||(Chon=='K')||(Chon=='k')) 
		{		
			break; 
		}
	} while (1); 

	for(int I=0;I<N;++I) 
	{ 
		Ng[I]->TinhLuong(); 
		Ng[I]->Xuat();
	} 
	return 0;
}
