#include "person.h" 

class BienChe: public Nguoi 
{ 
	protected: 
		float HeSoLuong;
		float HeSoPhuCap; 
	public: 
		BienChe(); 
		virtual void TinhLuong(); 
		virtual void Nhap();
}; 
