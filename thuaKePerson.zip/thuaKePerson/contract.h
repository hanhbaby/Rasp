#include "person.h"

 
class HopDong : public Nguoi 
  { 
	protected: 
		float TienCong; 
		float NgayCong; 
		float HeSoVuotGio; 
	public: 
		HopDong(); 
		virtual void TinhLuong();
		virtual void Nhap();
  };
