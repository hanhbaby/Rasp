#include <iomanip>
#include <iostream> 
#include <string.h> 

#include "person.h"

#include <iostream>
using namespace std; 

Nguoi::Nguoi()
{ 
	strcpy(HoTen,"");
	strcpy(MaSo,""); 
	Luong=0;  
} 
void Nguoi::Xuat() const 
{ 
	cout<<"Ma so:"<<MaSo<<",Ho va ten:"<<HoTen <<",Luong:"<<setiosflags(ios::fixed)<<setprecision(0)<<Luong<<endl;
} 
void Nguoi::Nhap()
{
	cout<<"Ma so:"; 
	cin>>MaSo; 
	cin.ignore();
	cout<<"Ho va ten:";
	cin.getline(HoTen,MAX_TEN); 
} 
