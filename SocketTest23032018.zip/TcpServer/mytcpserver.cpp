#include "mytcpserver.h"
#define file "/home/lehanh/Desktop/TcpServer/meo.jpg"

MyTcpServer::MyTcpServer(QObject *parent) :
    QObject(parent)
{
    server = new QTcpServer(this);

    // whenever a user connects, it will emit signal

    qDebug() << "Connection";

    connect(server, SIGNAL(newConnection()),
            this, SLOT(newConnection()));

    if(!server->listen(QHostAddress::Any, 8088))
    {
        qDebug() << "Server could not start";
    }
    else
    {
        qDebug() << "Server started!";
    }
}

void MyTcpServer::newConnection()
{
    qDebug() << "1";

    // need to grab the socket
    QTcpSocket *socket = server->nextPendingConnection();

    qDebug() << "Ready for read";

    readyRead(socket);

    qDebug() << "2";

    sendFile(socket);

    socket->close();
}

void MyTcpServer::readyRead(QTcpSocket *socket1)
{
    qDebug() << "3";

    socket1->waitForReadyRead(5000);
    qDebug() << "reading" << socket1->bytesAvailable();
    if (socket1->bytesAvailable() > 0)
    {
      qDebug() << "4";
      qDebug() << socket1->readAll();
    }
}

void MyTcpServer::sendFile(QTcpSocket *socket1)
{
    QFile inputFile(file);
    QByteArray read;
    /*
    QImage newInputFile(file);
    qDebug() << "Convert JPEG to BMP" << newInputFile.save("file.bmp");
    */
    inputFile.open(QIODevice::ReadOnly);

    while(1)
    {
        read.clear();
        read = inputFile.read(32768*8);
        qDebug() << "Read size: " << read.size();
        if(read.size() == 0)
        {
            break;
        }
        qDebug() << "Written: " << socket1->write(read);
        socket1->waitForBytesWritten(20000);
        read.clear();
    }
    inputFile.close();
    qDebug() << "File transfer completed";
}
