#ifndef MYTCPSERVER_H
#define MYTCPSERVER_H

#include <QObject>
#include <QTcpSocket>
#include <QTcpServer>
#include <QDebug>
#include <QFile>

class MyTcpServer : public QObject
{
    Q_OBJECT
public:
    explicit MyTcpServer(QObject *parent = 0);
    
signals:
    
public slots:
    void newConnection();
    void readyRead(QTcpSocket *);
    void sendFile(QTcpSocket *);

private:
    QTcpServer *server;
};

#endif // MYTCPSERVER_H
