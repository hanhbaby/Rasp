// 13.03,2018 test socket da run nhan message tu sever
//14.03.2018 giao tiep tung messsge theo tung nut nhan tren giao dien
//15.03.2018 nhan file image tu server
#include "sockettest.h"
#include "ui_sockettest.h"
#define address "127.0.0.1"
#define port 8088
sockettest::sockettest(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::sockettest)
{
    ui->setupUi(this);
}

sockettest::~sockettest()
{
    delete ui;
}
void sockettest::connectServer()
{
    //connect
    socket = new QTcpSocket(this);
    socket->connectToHost(address,port);
    if(socket->waitForConnected(3000))
    {
        socket->waitForReadyRead(3000);
        qDebug() << "reading"<< socket->bytesAvailable() ;
        if (socket->bytesAvailable() > 0)
        {
           qDebug() << socket->readAll();
        }
    }
    else
    {
        qDebug()<< "can't connected";
    }
    socket->write("hello server");
    socket->flush();
    socket->waitForBytesWritten(1000);
}
void sockettest::on_btnLock_clicked()
{
    if(ui->btnLock->text() == "unLock")
    {
        ui->btnLock->setText("lock");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("lock door");
            socket->flush();
            socket->waitForBytesWritten(1000);
        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
    else
    {
        ui->btnLock->setText("unLock");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("unlock door");
            socket->flush();
            socket->waitForBytesWritten(1000);
        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
}

void sockettest::on_btnVideo_clicked()
{
    if(ui->btnVideo->text() == "playVideo")
    {
        ui->btnVideo->setText("stopVideo");
        socket = new QTcpSocket(this);

        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("read data");
            socket->waitForBytesWritten(1000);
            socket->waitForReadyRead(10000);
            qDebug() << "reading" << socket->bytesAvailable();
            QByteArray data = socket->readAll();
            qDebug() << data.size();
            QPixmap mpixmap;
            mpixmap.loadFromData(data,"jpg");
            qDebug() << data.size();
            ui->display->setPixmap(mpixmap);
        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
    else
    {
        ui->btnVideo->setText("playVideo");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("undisplay");
            socket->flush();
            socket->waitForBytesWritten(3000);
        }
        else
        {
            qDebug()<< "can't connected";
        }
    }
}


//void sockettest::on_btnRead_clicked()
//{
//    socket = new QTcpSocket(this);

//    socket->connectToHost(address,port);
//    if(socket->waitForConnected(3000))
//    {
//        socket->write("read document");
//        socket->waitForBytesWritten(1000);
//        socket->waitForReadyRead(10000);
//        qDebug() << "reading" << socket->bytesAvailable();
//        QByteArray data = socket->readAll();
//        qDebug() << data.size();
//        QPixmap mpixmap;
//        mpixmap.loadFromData(data,"bmp");
//        qDebug() << data.size();
//        ui->diplayImage->setPixmap(mpixmap);

//    }

//}

void sockettest::on_btnAudio_clicked()
{

    if(ui->btnAudio->text() == "off")
    {
        ui->btnAudio->setText("on");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("turn on sound");
            socket->waitForBytesWritten(1000);
            socket->waitForReadyRead(3000);
            qDebug() << "reading" << socket->bytesAvailable();
            QByteArray data = socket->readAll();
            qDebug() << data.size();
            
            
            

        }
        else
        {
            qDebug()<< "can't connected";
        }
    }
    else
    {
        ui->btnAudio->setText("off");
    }

}
