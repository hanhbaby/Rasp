#ifndef SOCKETTEST_H
#define SOCKETTEST_H
#include "QTcpSocket"
#include "QDebug"
#include "QFile"
#include "QDataStream"
#include <QMainWindow>


namespace Ui {
class sockettest;
}

class sockettest : public QMainWindow
{
    Q_OBJECT

public:
    explicit sockettest(QWidget *parent = 0);
    ~sockettest();
    void connectServer();
     QString filename;


private slots:

    void on_btnLock_clicked();

    void on_btnVideo_clicked();

    //void on_btnRead_clicked();

    void on_btnAudio_clicked();

public slots:

private:
    Ui::sockettest *ui;

    QTcpSocket *socket;

};

#endif // SOCKETTEST_H
